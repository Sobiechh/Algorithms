inf = 1e10


def floyd_warshall(weights):
    V = len(weights)
    distance_matrix = weights
    for k in range(V):
        next_distance_matrix = [list(row) for row in distance_matrix]
        for i in range(V):
            for j in range(V):
                next_distance_matrix[i][j] = min(
                    distance_matrix[i][j], distance_matrix[i][k] + distance_matrix[k][j]
                )
        distance_matrix = next_distance_matrix
    return distance_matrix


graph = [[0, inf, inf, -3], [inf, 0, inf, 8], [inf, 4, 0, -2], [5, inf, 3, 0]]

print(floyd_warshall(graph))
